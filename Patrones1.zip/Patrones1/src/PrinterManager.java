public class PrinterManager {
    private static PrinterManager instance = null;

    private PrinterManager() {
        System.out.println("Printer Manager initialized\n");
    }

    public static PrinterManager getInstance() {
        if (instance == null) {
            instance = new PrinterManager();
        }
        return instance;
    }

    private int totalPrintedPages = 0;
    private String currentUser = "";

    public void print(String documentName, String userName, int pages) {
        if (pages <= 0) {
            System.out.println("Error: Invalid number of pages\n");
            return;
        }

        currentUser = userName;
        totalPrintedPages += pages;

        System.out.println("PRINTING...");
        System.out.println("Document: " + documentName);
        System.out.println("User: " + userName);
        System.out.println("Pages: " + pages);
        System.out.println("Print complete\n");
    }

    public void showStats() {
        System.out.println("PRINTER STATISTICS:");
        System.out.println("Total pages printed: " + totalPrintedPages);
        System.out.println("Last user: " + currentUser + "\n");
    }
}