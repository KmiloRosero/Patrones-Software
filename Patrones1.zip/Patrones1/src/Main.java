import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        PrinterManager printer = PrinterManager.getInstance();

        PrinterManager printer2 = PrinterManager.getInstance();
        System.out.println("Are they the same printer? " + (printer == printer2));
        System.out.println("(true = Singleton is working)\n");

        boolean running = true;

        while (running) {
            System.out.println("=== PRINTER MENU ===");
            System.out.println("1. Print document");
            System.out.println("2. View statistics");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");

            int option = scanner.nextInt();
            scanner.nextLine();

            if (option == 1) {
                System.out.print("\nDocument name: ");
                String doc = scanner.nextLine();

                System.out.print("Your name: ");
                String user = scanner.nextLine();

                System.out.print("Number of pages: ");
                int pages = scanner.nextInt();
                scanner.nextLine();

                printer.print(doc, user, pages);

            } else if (option == 2) {
                printer.showStats();

            } else if (option == 3) {
                System.out.println("\nGoodbye!");
                running = false;

            } else {
                System.out.println("Invalid option\n");
            }
        }

        scanner.close();
    }
}